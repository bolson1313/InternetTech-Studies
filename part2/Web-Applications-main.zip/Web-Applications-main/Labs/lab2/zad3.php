<?php
//Zad 2.3
$a=4;
define("B", 10);

$a = 7;
B = 22;

//b nie zadziała - jest to zmienna "stała", czyli jej wartość jest niezmienna