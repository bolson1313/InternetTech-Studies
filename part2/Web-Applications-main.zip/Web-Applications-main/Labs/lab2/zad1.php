<?php
//Zad 2.1
print "'Hello world!' znaczy witaj \"Witaj świecie!\".\n\tJest to napis pojawiający się w pierwszych programach.";