# Working with Bootstrao for the first time

My first experience with bootstrap as part of web application course.

We had to make a mockup site. Using mobile first approach get this site to be responsive.
