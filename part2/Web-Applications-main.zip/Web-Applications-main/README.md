## Excercises from HTML, CSS, JS, PHP, Laravel and other frameworks made on studies - 2nd year

Base uderstaning of frameworks, creating web applications.

<hr>

## Check idividual labs for further explanation
