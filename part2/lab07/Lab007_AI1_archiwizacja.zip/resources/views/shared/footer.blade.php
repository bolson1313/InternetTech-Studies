<footer class="container-fluid bg-body-tertiary">
    <div class="row text-center pt-2">
        <p>&copy; Wycieczki górskie &ndash; 2024</p>
    </div>
  </footer>
